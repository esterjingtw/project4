package ds.project4;

import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

import java.util.Scanner;

public class MongodbConnectionTest {

    public static void main(String[] args) {
        // MongoDB connection string with credentials
        final String mongoDbUri = "mongodb+srv://esterjingtw:Jtw001231@project4.6cphvt3.mongodb.net/?retryWrites=true&w=majority";

        // Using try-with-resources for automatic MongoClient closure
        try (MongoClient client = MongoClients.create(mongoDbUri)) {
            MongoDatabase db = client.getDatabase("myFirstDatabase");
            MongoCollection<Document> collection = db.getCollection("myFirstCollection");

            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter text to save in the database: ");
            String userInput = scanner.nextLine();

            Document newDocument = new Document("name", "User Entry")
                    .append("value", userInput);
            collection.insertOne(newDocument);
            System.out.println("Input successfully saved to database!");

            System.out.println("Displaying all stored documents:");
            for (Document doc : collection.find()) {
                System.out.println(doc.toJson());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.err.println("Connection error with MongoDB Atlas: " + ex.getMessage());
        }
    }
}