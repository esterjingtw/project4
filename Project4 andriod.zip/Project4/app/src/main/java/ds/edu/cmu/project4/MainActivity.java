package ds.edu.cmu.project4;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText editTextJokeType = findViewById(R.id.editTextJokeType);
        Button buttonFetchJoke = findViewById(R.id.buttonFetchJoke);
        final TextView textViewJoke = findViewById(R.id.textViewJoke);

        buttonFetchJoke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String jokeType = editTextJokeType.getText().toString();
                fetchJoke(jokeType, textViewJoke);
            }
        });
    }

    private void fetchJoke(String jokeType, final TextView textView) {
        String url = "http://localhost:8080/Project4/JokeServlet?type=" + jokeType;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the JSON response and display the joke
                        textView.setText(response); // Simplified for example
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText("That didn't work!");
            }
        });

        Volley.newRequestQueue(this).add(stringRequest);
    }
}
